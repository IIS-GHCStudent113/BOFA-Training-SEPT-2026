variable bucket_name {
  description = "The name of the S3 bucket"
  type        = string
}

# tags
variable tags {
  description = "Tags to set on bucket."
  type        = map(string)
  default     = {}
}