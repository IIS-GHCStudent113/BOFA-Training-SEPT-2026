terraform {
    backend "s3" {
        bucket = "amzn-s3-sm-2026" # 2026-sumit-s3-bucket
        key    = "path/to/my/key" # path/to/my/key
        region = "us-west-1"
        use_lockfile = true
      
    }
}