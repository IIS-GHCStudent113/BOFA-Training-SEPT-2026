# Copyright (c) HashiCorp, Inc.
# SPDX-License-Identifier: MPL-2.0

# Output variable definitions

output "vpc_public_subnets" {
  description = "IDs of the VPC's public subnets"
  value       = module.vpc.public_subnets
}

output "ec2_instance_public_ips" {
  description = "Public IP addresses of EC2 instances"
  value       = module.ec2_instances[*].public_ip
}


output "s3_domain" {
  description = "Domain name of the bucket"
  value       = module.website_s3_bucket_module.domain  #locally named <website_s3_bucket_module> module coming from main.tf
  # awlawy use output name form module

}


output "s3_bucket_name" {
  description = "Name of the S3 bucket"
  value       = module.website_s3_bucket_module.name
}


