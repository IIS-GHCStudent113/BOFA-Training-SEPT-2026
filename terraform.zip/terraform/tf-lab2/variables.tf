variable "instance_name" {
  description    = "Name tag for EC2 instance - Sumit here for testing"
  type           = string
  default        = "Lab2-TF-example-Sumit-Mistry"
}