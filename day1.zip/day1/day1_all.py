print("hello")


### Step 1: Basic GET Request
# Let's start with a simple GET request to retrieve data from an API.

import requests
import json

# # Make a GET request to a public API
response = requests.get('https://jsonplaceholder.typicode.com/posts/1')

# Check if request was successful
if response.status_code == 200:
    data = response.json()
    print(json.dumps(data, indent=2))
    print(data)
else:
    print(f"Error: {response.status_code}")







### Step 2: Making POST Requests
# Create new resources using POST requests.
import requests

# Data to send in the POST request
new_post = {
    'title': 'My New Post',
    'body': 'This is the content of my post',
    'userId': 1
}

# Make a POST request
response = requests.post(
    'https://jsonplaceholder.typicode.com/posts',
    json=new_post
)

# Check response
if response.status_code == 201:
    created_post = response.json()
    print("Created post:", created_post)
else:
    print(f"Error: {response.status_code}")


### Step 3: Adding Headers
# Learn how to add custom headers to your requests.

import requests

# Define headers
headers = {
    'User-Agent': 'Python API Lab Client',
    'Accept': 'application/json'
}

# Make request with headers
response = requests.get(
    'https://jsonplaceholder.typicode.com/posts/1',
    headers=headers
)

print(f"Status Code: {response.status_code}")
print(f"Headers: {response.headers}")
print(f"Data: {response.json()}")


### Step 4: Handling Query Parameters
# Add query parameters to your requests for filtering and pagination.

import requests

# Parameters as a dictionary
params = {
    'page': 1,
    'limit': 10,
    'sort': 'desc'
}

# Make GET request with parameters
response = requests.get(
    'https://jsonplaceholder.typicode.com/posts',
    params=params
)

# URL with parameters will be printed
print(f"Request URL: {response.url}")
print(f"Results: {response.json()[:2]}")  # Print first 2 results


### Step 5: PUT and PATCH Requests
# Update existing resources using PUT and PATCH.

import requests

# PUT request (full update)
put_data = {
    'id': 1,
    'title': 'Updated Title',
    'body': 'Updated body content',
    'userId': 1
}

put_response = requests.put(
    'https://jsonplaceholder.typicode.com/posts/1',
    json=put_data
)

print("PUT Response:")
print(f"Status Code: {put_response.status_code}")
print(f"Updated Data: {put_response.json()}\n")

# PATCH request (partial update)
patch_data = {
    'title': 'Only Update Title'
}

patch_response = requests.patch(
    'https://jsonplaceholder.typicode.com/posts/1',
    json=patch_data
)

print("PATCH Response:")
print(f"Status Code: {patch_response.status_code}")
print(f"Updated Data: {patch_response.json()}")


### Step 6: DELETE Requests
# Remove resources using DELETE requests.

import requests

# Make DELETE request
response = requests.delete('https://jsonplaceholder.typicode.com/posts/1')

# Check if deletion was successful
if response.status_code == 200:
    print("Resource deleted successfully")
else:
    print(f"Error deleting resource: {response.status_code}")



### Step 7: Error Handling
# Implement proper error handling for your API requests.
import requests
from requests.exceptions import RequestException

def make_api_request(url):
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raises an HTTPError for bad responses
        return response.json()
    
    except requests.exceptions.HTTPError as http_err:
        print(f"HTTP error occurred: {http_err}")
    except requests.exceptions.ConnectionError as conn_err:
        print(f"Error connecting to server: {conn_err}")
    except requests.exceptions.Timeout as timeout_err:
        print(f"Timeout error: {timeout_err}")
    except requests.exceptions.RequestException as err:
        print(f"An error occurred: {err}")
    
    return None

# Test with valid URL
print("\nTesting valid URL:")
result = make_api_request('https://jsonplaceholder.typicode.com/posts/1')
if result:
    print("Success! Retrieved data:", result)
else:
    print("Failed to retrieve data")

# Test with 404 error
print("\nTesting 404 error:")
result = make_api_request('https://jsonplaceholder.typicode.com/posts/999')
if result:
    print("Success! Retrieved data:", result)
else:
    print("Failed as expected - resource not found")

# Test with invalid URL
print("\nTesting invalid URL:")
result = make_api_request('https://invalid-url-that-does-not-exists.com')
if result:
    print("Success! Retrieved data:", result)
else:
    print("Failed as expected - invalid URL")


### Step 8: Working with Sessions
# Use sessions to maintain cookies and connection pools.

import requests

# Create a session
session = requests.Session()

# Set default headers for all requests in this session
session.headers.update({
    'User-Agent': 'Python API Lab Client',
    'Accept': 'application/json'
})

# Make multiple requests using the session
response1 = session.get('https://jsonplaceholder.typicode.com/posts/1')
response2 = session.get('https://jsonplaceholder.typicode.com/posts/2')

# Print results
print("First request:")
print(f"Status Code: {response1.status_code}")
print(f"Data: {response1.json()}\n")

print("Second request:")
print(f"Status Code: {response2.status_code}")
print(f"Data: {response2.json()}")

# Close the session when done
session.close()



